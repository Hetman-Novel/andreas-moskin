import * as nFunctions from "./modules/functions.js";
//nFunctions.nCustomCursor();
nFunctions.nWhatAscreen();
nFunctions.nHeader();
//nFunctions.isWebp();
nFunctions.dynamicAdapt();
//nFunctions.nLazyLoading();
nFunctions.nSelect();
nFunctions.nSpollers();

// Track Top Notification
const notification = document.querySelector('.top-notification');
if (notification) {
   const parent = notification.parentElement;
   if (parent) {
      parent.classList.add('there-is-a-top-notification');
      parent.parentNode.classList.add('there-top-notification');
   }
}

document.addEventListener('DOMContentLoaded', function() {

   let header = document.querySelector('header.header');
   if (header) {
      if (header.classList.contains('hidden-top')) {
         header.classList.remove('hidden-top');
      }
   }

   // Show search form
	const button = document.getElementById('button-show-search-form');
	const formBlock = document.getElementById('header-block-form');
	if (!button || !formBlock || !header) return;
	function toggleSearch() {
		const formIsVisible = formBlock.classList.contains('show');
		const headerHasSubmenu = header.classList.contains('show-submenu');

		if (formIsVisible && headerHasSubmenu) {
			formBlock.classList.remove('show');
			header.classList.remove('show-submenu');
		} else {
			formBlock.classList.add('show');
			header.classList.add('show-submenu');
		}
	}
	button.addEventListener('click', function (e) {
		e.stopPropagation();
		toggleSearch();
	});
	document.addEventListener('click', function (e) {
		const isClickInsideButton = button.contains(e.target);
		const isClickInsideForm = formBlock.contains(e.target);

		if (!isClickInsideButton && !isClickInsideForm) {
			formBlock.classList.remove('show');
			header.classList.remove('show-submenu');
		}
	});
   
   // block-with-video-clip
   const blocks = document.querySelectorAll('.block-with-video-clip');
   if (blocks.length > 0) {
      blocks.forEach(block => {
         const playButton = block.querySelector('.block-with-video-clip__play');
         if (playButton) {
            playButton.addEventListener('click', function () {
               // Remove the show-block class from the parent block
               block.classList.remove('show-block');

               // Launch the video in an iframe inside the same block
               const iframe = block.querySelector('iframe');
               if (iframe) {
                  const src = iframe.getAttribute('src');
                  if (!src.includes('autoplay=1')) {
                  const autoplaySrc = src.includes('?')
                     ? `${src}&autoplay=1`
                     : `${src}?autoplay=1`;
                  iframe.setAttribute('src', autoplaySrc);
                  }
               }
            });
         }
      });
   }

   // Function to equalize heights of .js-our-advantages-wrap-title
   function setEqualHeight() {
      const boxes = document.querySelectorAll('.js-our-advantages-wrap-title');
      
      if (window.innerWidth >= 481) {
         if (boxes.length > 0) {
            boxes.forEach(box => box.style.height = 'auto'); // Сброс высоты перед пересчетом

            let height = 0;
            boxes.forEach(box => {
               const currentHeight = box.offsetHeight;
               if (currentHeight > height) {
                  height = currentHeight;
               }
            });
            boxes.forEach(box => { // Устанавливаем одинаковую высоту
               box.style.height = `${height}px`;
            });
         }
      } else { // Сбрасываем высоту, если ширина меньше 481
         boxes.forEach(box => box.style.height = 'auto');
      }
   }
   setEqualHeight(); // Инициализация при загрузке страницы
   window.addEventListener('resize', setEqualHeight); // Добавление обработчика на изменение размера окна
   window.addEventListener('orientationchange', setEqualHeight); // Добавление обработчика на изменение ориентации экрана (для мобильных устройств)
});

nFunctions.nPopUp();
//nFunctions.backToTop();